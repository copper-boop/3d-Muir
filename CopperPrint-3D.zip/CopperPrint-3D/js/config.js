// Public configuration only. Never add API keys or service credentials here.
// Set this to your separately hosted HTTPS backend only after it is configured.
window.COPPERPRINT_API_URL = '';
