# CopperPrint 3D

A responsive, rustic workshop-style website for a local custom **PLA-only** 3D-printing service. It is a static frontend designed for GitHub Pages, with a deliberately separate, secure backend plan for print requests, private admin work, storage, and SMS notifications.

## What is included

```text
CopperPrint-3D/
├── index.html                 # Public website and request form
├── css/style.css              # Responsive rustic copper/wood visual system
├── js/script.js               # Client-side validation and interaction
├── assets/
│   ├── images/hero-workshop.svg
│   └── logo/copperprint-mark.svg
├── admin/index.html           # Secure-backend admin hand-off shell
├── backend/                   # Backend contract, schema, security plan
├── privacy.html / terms.html
└── .github/workflows/deploy-pages.yml
```

The color selector uses the Bambu Lab PLA Basic color names and swatches referenced in `js/script.js`. Color stock varies by region and time, so an administrator should edit that list to reflect workshop inventory and confirm availability with every customer.

## Local development

This is plain HTML, CSS, and JavaScript—no build or package installation is required. Open `index.html` in a browser, or use a static web server from the project folder:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Publish with GitHub Pages

1. In GitHub, create a new repository named `CopperPrint-3D`. Do not initialize it with a README if pushing this folder as-is.
2. In this project folder, initialize and push the repository:

   ```bash
   git init
   git add .
   git commit -m "Initial CopperPrint 3D website"
   git branch -M main
   git remote add origin https://github.com/USERNAME/CopperPrint-3D.git
   git push -u origin main
   ```

3. On GitHub, open **Settings → Pages**. Under **Build and deployment**, select **GitHub Actions** as the source.
4. The included `Deploy static site to GitHub Pages` workflow will publish each push to `main`. The first run may require approval in the repository’s Actions/Pages settings.
5. Once the workflow succeeds, GitHub displays the real public URL in the workflow environment and under **Settings → Pages**. It normally follows `https://USERNAME.github.io/CopperPrint-3D/`, but use the URL GitHub actually reports—no deployment URL is assumed by this project.

## Connect the backend (required before accepting requests)

The public form intentionally **does not send or retain private data** until it is connected to a secure backend. See [`backend/README.md`](backend/README.md) for required routes, security controls, schema, server-side environment variables, a Twilio SMS design for the workshop number, private file uploads, and administrator-only request management.

After the backend is live, set the backend URL in a deployment-specific configuration that produces `window.COPPERPRINT_API_URL` before `js/script.js` loads. Keep private API keys and SMS credentials on the server only. The admin endpoint must enforce real authentication; the static `admin/` page never contains customer data.

## Admin workflow

The backend admin dashboard should display customer, contact information, model link, platform, PLA color, quantity, scale, estimate, final price, pricing notes, meetup details, date, and status. Administrators review every request, set the final price manually, and progress it through: **New Request → Reviewing → Price Sent → Approved → Printing → Ready for Pickup → Completed**. `Cancelled` is available when needed.

## Custom domain

After the site works at its GitHub Pages address, open **Settings → Pages → Custom domain**, enter your domain, and follow GitHub’s DNS instructions at your domain provider. GitHub will provide the authoritative records. Enable **Enforce HTTPS** after DNS verification. If using a domain, update the backend’s allowed CORS origin to that domain.

## License and model notice

Customers are responsible for ensuring requested models are appropriately licensed for their intended use. CopperPrint 3D only accepts a model URL for review and does not automatically download, reproduce, or redistribute third-party models.
