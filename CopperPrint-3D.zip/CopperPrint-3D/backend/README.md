# Secure backend blueprint

GitHub Pages can host the public site, but it cannot safely accept private customer data, store uploads, authenticate an administrator, or send an SMS. Host this component separately (for example, a serverless API on Cloudflare Workers, Vercel Functions, Netlify Functions, Supabase Edge Functions, or a conventional server).

## Required routes

| Route | Purpose | Access |
| --- | --- | --- |
| `POST /requests` | Validate and store a request, then notify the workshop | public, rate-limited |
| `POST /uploads/sign` | Issue a short-lived signed upload URL | public, rate-limited |
| `GET /admin/login` | Begin secure administrator login | private auth provider |
| `GET /admin/requests` | List requests | authenticated admin only |
| `PATCH /admin/requests/:id` | Set final price, pricing notes, and status | authenticated admin only |

Use a database with row-level access controls. The server, not browser code, owns all Twilio and database credentials. Store uploaded images in a private bucket and return time-limited URLs only to authenticated administrators.

## Server-side environment variables

```text
DATABASE_URL=
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_FROM_NUMBER=
WORKSHOP_SMS_TO=747-441-0713
ADMIN_AUTH_ISSUER=
ALLOWED_ORIGIN=https://USERNAME.github.io
```

Never put these values in the Pages repository, GitHub Actions variables exposed to the browser, or `js/script.js`.

## Request record

Store: `name`, `email`, `phone`, `modelUrl`, `platform`, `material` (always `PLA`), `color`, `quantity`, `scale`, `customScale`, `estimatedPrice`, meetup fields, notes, date, `finalPrice`, `pricingNotes`, and `status`.

Allowed status workflow: `New Request → Reviewing → Price Sent → Approved → Printing → Ready for Pickup → Completed`. `Cancelled` is also allowed. Do not set `Printing` until the administrator has reviewed the model and confirmed final price.

## SMS body

After server-side validation, send exactly this content to the configured workshop number:

```text
NEW 3D PRINT REQUEST
Customer: [Name]
Contact: [Phone/Email]
Model: [URL]
Platform: [Platform]
Material: PLA
Color: [PLA Color]
Quantity: [Quantity]
Size: [Scale]
Estimated Price: [$4–$40]
Meetup: [Location]
Notes: [Notes]
```

Add CAPTCHA, server-side input validation, URL allow-listing, rate limiting, audit logging, and authenticated admin sessions before accepting production data.
